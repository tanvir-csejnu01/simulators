package  producer_consumer_newpackage;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BlinkLabel extends Thread
{
    Simulator f= new Simulator();
    public BlinkLabel(Simulator j)
    {
       this. f= j;
      }
    @Override
    public void  run()
    {
        while(f.isRunning==true)
        {
            
            if(f.messageLabel.getText() ==null)
            {
                f.messageLabel.setText("Synchronized Producer Consumer Problem where a Producer produces items(10 items) and a Consumer consumes. ");  
            }
            else{
               
                 f.messageLabel.setText(null); 
             }
            try {
                sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(BlinkLabel.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
    }
    
}
