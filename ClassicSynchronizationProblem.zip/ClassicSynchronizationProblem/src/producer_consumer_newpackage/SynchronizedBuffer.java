
package producer_consumer_newpackage;
// SynchronizedBuffer synchronizes access to a single shared integer.
 
   public class SynchronizedBuffer implements Buffer
   {
      private int buffer = -1; // shared by producer and consumer threads
     private boolean occupied = false; // count of occupied buffers
     Simulator sim =new Simulator();
     public SynchronizedBuffer(Simulator s)
     {
         this.sim =s;
      }
 
     // place value into buffer
     public synchronized void set( int value )
     {
        // while there are no empty locations, place thread in waiting state
         if(sim.isRunning==true){
        while ( occupied )
        {
           // output thread information and buffer information, then wait
           try
           {
             //System.out.println( "Producer tries to produce." );
               sim.string += "Producer tries to produce.\n\n\n";
              sim.operationLabel.setText("producer tries to produce");
              sim.allStatusArea.setText(sim.string);
              sim.bufferLabel.setText("-");
              sim.occupiedLabel.setText("-");
              displayState( "Buffer full. Producer waits." );
              wait();
           } // end try
           catch ( InterruptedException exception )
           {
              exception.printStackTrace();
           } // end catch
        } // end while

        buffer = value; // set new buffer value

        // indicate producer cannot store another value 
        // until consumer retrieves current buffer value
        occupied = true;                                

        displayState( "Producer produces " + buffer );

        notify(); // tell waiting thread to enter runnable state
     } // end method set; releases lock on SynchronizedBuffer
     }
     // return value from buffer
    @Override
     public synchronized int get()
     {
        // while no data to read, place thread in waiting state
         if(sim.isRunning==true){
        while ( !occupied )
        {
           // output thread information and buffer information, then wait
           try
           {
              //System.out.println( "Consumer tries to read." );
              sim.string+="Consumer tries to consume.\n\n\n";
              sim.operationLabel.setText("Consumer tries to consume.");
              sim.allStatusArea.setText(sim.string);
              sim.bufferLabel.setText("");
              sim.occupiedLabel.setText("");
              displayState( "Buffer empty. Consumer waits." );
              wait();
           } // end try
           catch ( InterruptedException exception )
           {
              exception.printStackTrace();
           } // end catch
        } // end while

        // indicate that producer can store another value
        // because consumer just retrieved buffer value  
        occupied = false;                                

        int readValue = buffer; // store value in buffer
        displayState( "Consumer consumes " + readValue );

       notify(); // tell waiting thread to enter runnable state
         
        return readValue;
     } // end method get; releases lock on SynchronizedBuffer
         return 0;
     }
     // display current operation and buffer state
     public void displayState( String operation )
     {
       // System.out.printf( "%-40s%d\t\t%b\n\n", operation, buffer,
           //occupied );
        sim.string+=operation+"\t\t"+buffer+"\t\t"+occupied+"\n\n\n";
        sim.operationLabel.setText(operation);
        sim.allStatusArea.setText(sim.string);
        sim.bufferLabel.setText(String.valueOf(buffer));
        sim.occupiedLabel.setText(occupied+"");
     } // end method displayState
  } // end class SynchronizedBuffer


 

