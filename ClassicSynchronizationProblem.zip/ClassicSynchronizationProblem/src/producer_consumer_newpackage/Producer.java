
package producer_consumer_newpackage;
// Producer's run method stores the values 1 to 10 in buffer.
   import java.util.Random;
 
   public class Producer implements Runnable
  {
     private static Random generator = new Random();
     Simulator sim =new Simulator();
     private Buffer sharedLocation; // reference to shared object
      // constructor
     public Producer( Buffer shared , Simulator s)
     {
         this.sharedLocation = shared;
         this.sim =s;
     } // end Producer constructor

     // store values from 1 to 10 in sharedLocation
     public void run()                             
     {    
         int sum = 0;
          String st="";
        for ( int count = 1; count <= 10; count++ )
        {
           try // sleep 0 to 3 seconds, then place value in Buffer
           {
              Thread.sleep( generator.nextInt( 20000 ) ); // sleep thread
              sharedLocation.set( count ); // set value in buffer
              sum += count; // increment sum of values
             //System.out.printf( "\t%2d\n", sum );
          } // end try
           // if sleeping thread interrupted, print stack trace
           catch ( InterruptedException exception )
           {
          exception.printStackTrace();           
               } // end catch
           } // end for

       // System.out.printf( "\n%s\n%s\n", "Producer done producing.",
           //"Terminating Producer." );
        sim.string +="Producer done producing.So terminating Producer !\n\n\n";
        st+="Producer done producing.So terminating Producer !";
        sim.operationLabel.setText(st);
        sim.bufferLabel.setText("-");
        sim.occupiedLabel.setText("-");
        sim.allStatusArea.setText(sim.string);
        
     } // end method run
  } 



