
package producer_consumer_newpackage;
// Buffer interface specifies methods called by Producer and Consumer.
public interface Buffer
   {
      public void set( int value ); // place int value into Buffer
      public int get(); // return int value from Buffer
  } 

 


