
package producer_consumer_newpackage;

// Consumer's run method loops ten times reading a value from buffer.
import java.util.Random;

   public class Consumer implements Runnable
  {
      private static Random generator = new Random();
      Simulator sim =new Simulator();
     private Buffer sharedLocation; // reference to shared object
 
     // constructor
     public Consumer( Buffer shared , Simulator s)
     {
        sharedLocation = shared;
        this.sim =s;
     } // end Consumer constructor

     // read sharedLocation's value four times and sum the values
    @Override
     public void run()                                           
     {
        int sum = 0;
          String st=""; 
        for ( int count = 1; count <= 10; count++ )
        {
           // sleep 0 to 3 seconds, read value from buffer and add to sum
           try
           {
              Thread.sleep( generator.nextInt( 20000 ) );
              sum += sharedLocation.get();
             // System.out.printf( "\t\t\t%2d\n", sum );
           } // end try
           // if sleeping thread interrupted, print stack trace
           catch ( InterruptedException exception )
           {
              exception.printStackTrace();
           } // end catch
        } // end for

       // System.out.printf( "\n%s %d.\n%s\n",
          // "Consumer read values totaling", sum, "Terminating Consumer." );
         sim.string+="Consumer consumes values totaling: "+sum+".So terminating Consumer !\n";
        st+="Consumer consumes values totaling: "+sum+".So terminating Consumer !";
         sim.operationLabel.setText(st);
         sim.bufferLabel.setText("");
         sim.occupiedLabel.setText("");
         sim.allStatusArea.setText(sim.string);
         
         
     } // end method run
 } 

