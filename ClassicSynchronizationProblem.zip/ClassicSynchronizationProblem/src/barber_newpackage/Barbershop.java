
package barber_newpackage;

import java.util.concurrent.Semaphore;

/**
 * Class Barbershop
 * 
 * @author Tanvir Lincon 
 */
public class Barbershop extends Thread {
        
        public BarberShopInJframe app;

	public Semaphore barber;
	public Semaphore customer;
	public Semaphore haircut;
	public Semaphore mutex; // mutex lock for the chairs
        
        private Thread barney;
        
        // speed in ms
        private final int NEW_CUSTOMER_SPEED =6000;
        private final int HAIRCUT_SPEED = 8000;
        // how long should the barber rest between each haircut?
        private final int BARBER_PAUSE = 3000;
        // the actual speed is randomly chosen  lies between the values:
        // [ _SPEED - DEVIATION ; _SPEED + DEVIATION ]
        private final int DEVIATION= 3000;
	
        /**
         * Constructor.
         * 
         * @param   app
         *          The Jframe.
         */
	public Barbershop(BarberShopInJframe app)
	{
              this.app = app;
		this.barber = new Semaphore(0);
		this.customer = new Semaphore(0);
		this.haircut = new Semaphore(0);
		this.mutex = new Semaphore(1);
		this.customers = 0;
                
                // Introduce a new barber.
                barney = new Thread( new Barber() );
	}
        
        /**
         * Run.
         */
        @Override
        public void run()
        {
            barney.start();
            int r;
            while( app.isRunning ) {
                try {
                   // app.status.setText("Single Sleeping Barber Problem Simulation.");
                    // Wait for a random time.
                    r = (int) Math.round( 2 * DEVIATION * Math.random() );
                    r += ( NEW_CUSTOMER_SPEED - DEVIATION );
                    sleep(r);     
                    // Make a new customer.
                    new Thread(new Customer()).start();
                } catch (InterruptedException ex) {}
            }
        }
	
	/************************************************
	 * barber                                       *
	 ************************************************/
	
        /**
         * Barber class.
         */
	class Barber implements Runnable
	{
                /**
                 * Constructor.
                 */
		public Barber()
		{
		}

                /**
                 * Run.
                 */
		@Override
		public void run()
		{
			while( app.isRunning ) {
				
				if( ! app.lblBarber.getText().equals("Sleeping...") )
                                    app.lblBarber.setText("Sleeping...");
				
				// Sleep.
				try {
					customer.acquire();
				} catch (InterruptedException e) {}
				
                                app.lblLatestEvent.setText("We have a new customer!");
				
				// New customer -> call the next customer.
				barber.release();
				
				// Cut.
                                app.lblBarber.setText("Cutting...");
                                
                                int r = (int) Math.round( 2 * DEVIATION * Math.random() );
                                r += ( HAIRCUT_SPEED - DEVIATION );
                               // System.out.println(r+"Time:");
                               // app.CuttingTime.setText(String.valueOf(r));
                                
                                try{
                                    sleep(r);
                               app.CuttingTime.setText(String.valueOf(r)+" ms");
                                }catch(Exception e){}
				
                                // Done.
				haircut.release();
                                
                                // Take a break.
                                app.lblBarber.setText("Taking a break...");
                                try {
                                    sleep(BARBER_PAUSE);	
                                }catch(Exception whatever){}
			}
		}
	}
	
	/************************************************
	 * customers                                    *
	 ************************************************/
	
	private final int MAXIMUM_CUSTOMERS = 5;
	private int customers;
	
        /**
         * Customer class.
         */
	class Customer implements Runnable
	{
                public String name;
                public int chair = app.chairs.length;
                
                /**
                 * Constructor.
                 */
		public Customer()
		{
			this.name = generateName();
		}

                /**
                 * Run.
                 */
		@Override
		public void run()
		{
                        app.lblLatestEvent.setText("A customer tries to enter our barbershop...");
			
			// Attempt to enter the barbershop.
			try {
				mutex.acquire();
			} catch (InterruptedException e) {}

			// Is there still room left?
			if( customers <= MAXIMUM_CUSTOMERS) {
                            
                                app.lblLatestEvent.setText("The barbershop has a new customer.");
                            
                                // Sit.
				customers++;
                                while( this.chair == app.chairs.length )
                                    this.chair = findChair(this.name);
                                
                                   app.lblCustomers.setText( Integer.toString(customers) );
				
				// Release the mutex lock.
				mutex.release();
				
				// Call the barber.
				customer.release();
				
				// Wait for your turn.
				try {
					barber.acquire();
				} catch (InterruptedException e) {}
                                
                                // Get up and go to the barberchair.
                                app.chairs[this.chair].setText("");
                                app.lblBarberChair.setText(this.name);
                                app.CuttingTime.setText("For customer"+this.name+" cutting time : ");
				
				// Get haircut.
                                app.lblLatestEvent.setText("Customer gets haircut.");
                                
                                try {
					haircut.acquire();
				} catch (InterruptedException e) {}
                                
                                // Done.
				try {
					mutex.acquire();
				} catch (InterruptedException e) {}
                                
                                // Get up.
				app.lblBarberChair.setText("");
                                
                                // Leave.
                                customers--;
                                
                                // Update # customers.
                                app.lblCustomers.setText( Integer.toString(customers) );
                                
                                app.lblLatestEvent.setText("The customer leaves with a nice haircut.");
				
			}else{
				
                                // Leave.
                                app.lblLatestEvent.setText("A customer leaves without a haircut with gloomy mind.");
				
			}
                        
                        // Release the mutex lock.
			mutex.release();
			
		}
                
                /**
                 * Pretty self-explaining...
                 * 
                 * @return  A new name.
                 */
                public String generateName()
                {
              
                        String [] mk = { "Tanvir", "Mahmud", "Lincon", "Shimul", 
                            "Zobayer", "Sajib", "Sujon", "Jahid", 
                            "Tuhin", "Mamun", "Afijer", "Debashis", 
                            "Alamin", "Firoz", "Saifur", "Emon", "Tareq", "Romel" };

                            String newName=" ";
                            int r;
                      
                           r = (int)Math.round( Math.random()* (mk.length-1) );
                            newName+=mk[r];
                            newName=newName.toUpperCase();
                      
                        return newName;
                }

                /**
                 * Find an available chair and take a seat.
                 * This will only be executed if there is at least 1 chair available.
                 * So we are already granted the mutex lock in this case...
                 * 
                 * @param   name
                 *          Name of the customer.
                 * @return  The number of the chair.
                 */
                public int findChair(String name)
                {
                    for( int i=0 ; i<app.chairs.length ; i++ )
                        if( app.chairs[i].getText().equals("") ) {
                            app.chairs[i].setText(name);
                            return i;
                        }

                    // No chair was found.
                    return app.chairs.length;
                }
	}

}