package  barber_newpackage;
import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;

public class BlinkLabel extends Thread
{
    BarberShopInJframe f= new BarberShopInJframe();
    Icon i= new javax.swing.ImageIcon(getClass().getResource("image-03.jpg"));
     Icon  img_1= new javax.swing.ImageIcon(getClass().getResource("image-01.jpg"));
     Icon  img_2= new javax.swing.ImageIcon(getClass().getResource("image-02.jpg"));
    Icon  j= new javax.swing.ImageIcon(getClass().getResource("FCB.jpg"));
    public BlinkLabel(BarberShopInJframe j)
    {
       this. f= j;
      }


    public void  run()
    {
        while(f.isRunning)
        {
            if(f.statuslabel.getText() ==null)
            {
                f.statuslabel.setText("\tWelcome to Single Sleeping Barber problem simutaion.");
                 f.picLabel.setIcon(i); 
                 f.wLabel.setIcon(img_1);
            }
            else{
                f.statuslabel.setText(null);
                f.picLabel.setIcon(j);
               f.wLabel.setIcon(img_2);
             }
            try {
                sleep(1800);
            } catch (InterruptedException ex) {
                Logger.getLogger(BlinkLabel.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
    }
    
}
