/***
 * this class includes the philosopher's 
 *  food distribution and determines 
 *  who will eat or not.
 */
package dining_philosopher_package;

import javax.swing.Icon;

/*Designed by Tanvir Lincon */
class PhilosopherWithNoDeadlock implements Runnable
{
 
  PhilosopherJFrame frame =new PhilosopherJFrame();
  BuildSemaphore[] chopSticks;
  PhilosopherWithNoDeadlock[] philosophers;
  private String name[]={"C","C++","Java","C#","Php"};
  private int n;  // philosophers NO.
  private int id; // philosophers ID.
  private int count=1; // temporary counter...
  private Icon [] icon; 
  
  public PhilosopherWithNoDeadlock(int id, BuildSemaphore[] chopSticks, PhilosopherWithNoDeadlock[] p,PhilosopherJFrame f)
  {
    this.frame =f;
    this.id = id;
    this.chopSticks = chopSticks;
    this.philosophers = p;
    n = chopSticks.length;
    // icon setting 
       icon =new Icon[5];
       icon[0]= new javax.swing.ImageIcon(getClass().getResource("pic-1.jpg"));
       icon[1]= new javax.swing.ImageIcon(getClass().getResource("pic-2.jpg"));
       icon[2]= new javax.swing.ImageIcon(getClass().getResource("pic-3.jpg"));
       icon[3]= new javax.swing.ImageIcon(getClass().getResource("pic-4.jpg"));
       icon[4]= new javax.swing.ImageIcon(getClass().getResource("pic-5.jpg"));
   
  }
 
    @Override
  public void run()
  {
     
    while(frame.isRunning==true)
    {
        if(count==1){  
         toSeat();
        count=2;
        }
        else{
       eatAndThink();
        }
        count=2;
    }
  }
  
   private void eatAndThink()
   {
      frame.status[id].setText("is trying  to take left chopstick");
      frame.pName[id].setText(name[id]);
      frame.fork[id].setText("Busy                     Free");
      
      chopSticks[id].acquire();      // pick left chopstick
      
      frame.status[id].setText("has taken left chopstick and try to take right.");
      frame.pName[id].setText(name[id]);
        frame.fork[id].setText("Free                    Busy");
      chopSticks[(id+1) % n].acquire();    // pick right chopstick
      
     frame.status[id].setText("has taken right chopstick and eating..."); 
     frame.pName[id].setText(name[id]);
    frame.fork[id].setText("Busy                    Busy");
     SleepUtilities.nap();     // eating

      chopSticks[id].release();     // return left chopstick
    
      frame.status[id].setText("put her  left chopstick");
      frame.pName[id].setText(name[id]);
        frame.fork[id].setText("Free                    Busy");
      chopSticks[(id+1) % n].release(); // return right chopstick  
     
       frame.status[id].setText( "put her both chopsticks and thinking.");
      frame.pName[id].setText(name[id]);
       frame.fork[id].setText("Free                    Free");
      
     SleepUtilities.nap();     // thinking
    }
  
  private void toSeat()
  {  
        for(int i=0;i<5;i++) { 
      frame.pName[i].setText(name[i]);
      frame.status[i].setText("is setting on the table.");
      frame.fork[i].setText("Free                     Free");
      frame.picAnimation[i].setIcon(icon[i]);
      SleepUtilities.toEqualSleep();
      }
      
   }
}