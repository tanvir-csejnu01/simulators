/*
 * This class contais the simulation frame
 * all relavent class call here.
 */
package dining_philosopher_package;

import editor_Pane.ViewTextEditor;
import java.util.concurrent.Semaphore;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author TnvirLncon
 */
public class PhilosopherJFrame extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public JLabel [] status;
    public JLabel [] pName;
    public JLabel [] fork;
    int PHILOSOPHERS_NO =5;
    public JLabel [] picAnimation;
    
    public boolean  isRunning;
    
    
    // constructor
    public PhilosopherJFrame() {
        initComponents();
        status =new JLabel[5];
        
        this.status[0] =one;
        this.status[1] =two;
        this.status[2] =three;
        this.status[3] =four ;
        this.status[4] =five;
                
        pName =new JLabel[5];
        this.pName[0] =phOne;
        this.pName[1] =phTwo;
        this.pName[2] =phThree;
        this.pName[3] =phFour;
        this.pName[4] =phFive;
        
        fork =new JLabel[5];
        this.fork[0] =forkOne;
        this.fork[1] =forkTwo;
        this.fork[2] =forkThree;
        this.fork[3] =forkFour;
        this.fork[4] =forkFive;
        
     
       setIconImage(new javax.swing.ImageIcon(getClass().getResource("cpu.jpg")).getImage());
    
       
        picAnimation =new JLabel[5];
           this.picAnimation[0]=pic_01;
           this.picAnimation[1]=pic_02;
           this.picAnimation[2]=pic_03;
           this.picAnimation[3]=pic_04;
           this.picAnimation[4]=pic_05;
    }

   // variable declaration here....
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        one = new javax.swing.JLabel();
        two = new javax.swing.JLabel();
        three = new javax.swing.JLabel();
        four = new javax.swing.JLabel();
        five = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        phOne = new javax.swing.JLabel();
        phTwo = new javax.swing.JLabel();
        phThree = new javax.swing.JLabel();
        phFour = new javax.swing.JLabel();
        phFive = new javax.swing.JLabel();
        start = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        forkOne = new javax.swing.JLabel();
        forkTwo = new javax.swing.JLabel();
        forkThree = new javax.swing.JLabel();
        forkFour = new javax.swing.JLabel();
        forkFive = new javax.swing.JLabel();
        deadlockStatus = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        rootPicture = new javax.swing.JLabel();
        pic_01 = new javax.swing.JLabel();
        pic_02 = new javax.swing.JLabel();
        pic_03 = new javax.swing.JLabel();
        pic_04 = new javax.swing.JLabel();
        pic_05 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        deadFree = new javax.swing.JRadioButtonMenuItem();
        deadLock = new javax.swing.JRadioButtonMenuItem();
        problemContent = new javax.swing.JMenu();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        codeContent = new javax.swing.JCheckBoxMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("                                                        Dining Philosopher Problem Simulator-Designed By Tanvir Lincon.");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createCompoundBorder());

        one.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        one.setIconTextGap(8);

        two.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        two.setIconTextGap(8);

        three.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        three.setIconTextGap(8);

        four.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        four.setIconTextGap(8);

        five.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        five.setIconTextGap(8);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setText("Name");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setText("1 :");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setText("2 :");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setText("3 :");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel5.setText("4 :");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel6.setText("5 :");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 102, 102));
        jLabel7.setText("Their Activities");

        phOne.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        phOne.setForeground(new java.awt.Color(0, 0, 255));

        phTwo.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        phTwo.setForeground(new java.awt.Color(0, 0, 255));

        phThree.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        phThree.setForeground(new java.awt.Color(0, 0, 255));

        phFour.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        phFour.setForeground(new java.awt.Color(0, 0, 255));

        phFive.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        phFive.setForeground(new java.awt.Color(0, 0, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(phFive))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(phOne))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(phTwo))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(phThree))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(phFour))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel1)))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(four, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)
                    .addComponent(five, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(one, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(two, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(three, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel7))
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(phOne)
                    .addComponent(one))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(phTwo)
                    .addComponent(two)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(phThree))
                    .addComponent(three))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(phFour)
                        .addComponent(jLabel5))
                    .addComponent(four, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(five)
                    .addComponent(jLabel6)
                    .addComponent(phFive))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        start.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        start.setText("Play");
        start.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        start.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createCompoundBorder());

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 0));
        jLabel8.setText("Left Fork");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 0, 153));
        jLabel9.setText("Right Fork");

        forkOne.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        forkOne.setForeground(new java.awt.Color(255, 102, 0));

        forkTwo.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        forkTwo.setForeground(new java.awt.Color(255, 102, 0));

        forkThree.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        forkThree.setForeground(new java.awt.Color(255, 102, 0));

        forkFour.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        forkFour.setForeground(new java.awt.Color(255, 102, 0));

        forkFive.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        forkFive.setForeground(new java.awt.Color(255, 102, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(forkOne, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(forkTwo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(forkThree, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(forkFour, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(forkFive, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel9)
                        .addGap(23, 23, 23)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addComponent(forkOne)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(forkTwo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(forkThree)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(forkFour)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(forkFive)
                .addContainerGap())
        );

        deadlockStatus.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        deadlockStatus.setForeground(new java.awt.Color(0, 153, 255));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel11.setText("Status");

        rootPicture.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dining_philosopher_package/two.jpg"))); // NOI18N

        jMenuBar1.setBackground(java.awt.Color.white);
        jMenuBar1.setToolTipText("Menu bar");

        jMenu1.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Exit");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Options");

        buttonGroup1.add(deadFree);
        deadFree.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        deadFree.setText("Deadlock Free");
        deadFree.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deadFreeActionPerformed(evt);
            }
        });
        jMenu2.add(deadFree);

        buttonGroup1.add(deadLock);
        deadLock.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        deadLock.setText("Deadlock Condition");
        deadLock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deadLockActionPerformed(evt);
            }
        });
        jMenu2.add(deadLock);

        jMenuBar1.add(jMenu2);

        problemContent.setText("Help");

        buttonGroup2.add(jCheckBoxMenuItem1);
        jCheckBoxMenuItem1.setText("About  Problem");
        jCheckBoxMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxMenuItem1ActionPerformed(evt);
            }
        });
        problemContent.add(jCheckBoxMenuItem1);

        buttonGroup2.add(codeContent);
        codeContent.setText("Implemented Code");
        codeContent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codeContentActionPerformed(evt);
            }
        });
        problemContent.add(codeContent);

        jMenuBar1.add(problemContent);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(330, 330, 330)
                .addComponent(start)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pic_01, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(pic_03, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(pic_05, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(pic_04, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pic_02, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(deadlockStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(98, 98, Short.MAX_VALUE)
                        .addComponent(rootPicture, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pic_01, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pic_02, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(pic_03, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pic_04, javax.swing.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel11)
                                .addComponent(deadlockStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(pic_05, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(rootPicture, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(start)
                .addGap(23, 23, 23))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void startActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startActionPerformed
        // TODO add your handling code here:
        if(start.isSelected())
        {
            start.setText("Stop");
            isRunning =true;
       // if deadlockFree option selected then it works..     
       if(deadFree.isSelected()){
                  // objects declaration here...
                 BuildSemaphore[] chopSticks = new BuildSemaphore[PHILOSOPHERS_NO];
                Thread[] philosophers = new Thread[PHILOSOPHERS_NO];
               PhilosopherWithNoDeadlock[] p = new PhilosopherWithNoDeadlock[PHILOSOPHERS_NO];
            
              for (int i=0; i<PHILOSOPHERS_NO; i++)
                {
                chopSticks[i] = new BuildSemaphore(1);
                 p[i] = new PhilosopherWithNoDeadlock(i, chopSticks, p,PhilosopherJFrame.this);
                 philosophers[i] = new Thread(p[i]); 
                  }
           for (int i=0; i<PHILOSOPHERS_NO; i++){
                 philosophers[i].start();
           }
           }
       
       // deadLock option
       else if(deadLock.isSelected())
         {
               Semaphore[] chopSticks = new Semaphore[PHILOSOPHERS_NO];
               Thread[] philosophers = new Thread[PHILOSOPHERS_NO];
               PhilosopherWithDeadlock[] p = new PhilosopherWithDeadlock[PHILOSOPHERS_NO];
             for (int i=0; i<PHILOSOPHERS_NO; i++)
               {
               chopSticks[i] = new Semaphore(1,true);
               p[i] = new PhilosopherWithDeadlock(i, chopSticks, p,PhilosopherJFrame.this);
              philosophers[i] = new Thread(p[i]); 
               }
            for (int i=0; i<PHILOSOPHERS_NO; i++)
               philosophers[i].start();
            
                
            } // end of nested if else
       else{
            String s="Sorry !!!!  Wrong selection..";
           JOptionPane.showMessageDialog(null,s,"Selection Error", JOptionPane.ERROR_MESSAGE);
            }
         } // end of first if
        
        
        else
        {
            start.setText("Play");
            isRunning =false;
            for(int i=0;i<5;i++)
            {
                status[i].setText("");
                fork[i].setText("");
             picAnimation[i].setIcon(null);
             }
         }
        
    }//GEN-LAST:event_startActionPerformed

    private void deadLockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deadLockActionPerformed
        // TODO add your handling code here:
        deadlockStatus.setText("Deadlock Case !");
    }//GEN-LAST:event_deadLockActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void deadFreeActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
        deadlockStatus.setText("Deadlock Free.");
    }

    private void jCheckBoxMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {                                                   
        // TODO add your handling code here:
      ViewTextEditor edt =new ViewTextEditor();
        edt.showTextMessage("/dining_philosopher_package/problem.html");
        edt.show();
    }

    private void codeContentActionPerformed(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        ViewTextEditor edt =new ViewTextEditor();
        edt.showTextMessage("/dining_philosopher_package/code.html");
        edt.show();
    }

    
  /*  public static void main(String args[]) {
        /*
      
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new PhilosopherJFrame().setVisible(true);
            }
        });
    }*/
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBoxMenuItem codeContent;
    private javax.swing.JRadioButtonMenuItem deadFree;
    private javax.swing.JRadioButtonMenuItem deadLock;
    private javax.swing.JLabel deadlockStatus;
    private javax.swing.JLabel five;
    private javax.swing.JLabel forkFive;
    private javax.swing.JLabel forkFour;
    private javax.swing.JLabel forkOne;
    private javax.swing.JLabel forkThree;
    private javax.swing.JLabel forkTwo;
    private javax.swing.JLabel four;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel one;
    private javax.swing.JLabel phFive;
    private javax.swing.JLabel phFour;
    private javax.swing.JLabel phOne;
    private javax.swing.JLabel phThree;
    private javax.swing.JLabel phTwo;
    private javax.swing.JLabel pic_01;
    private javax.swing.JLabel pic_02;
    private javax.swing.JLabel pic_03;
    private javax.swing.JLabel pic_04;
    private javax.swing.JLabel pic_05;
    private javax.swing.JMenu problemContent;
    private javax.swing.JLabel rootPicture;
    private javax.swing.JRadioButton start;
    private javax.swing.JLabel three;
    private javax.swing.JLabel two;
    // End of variables declaration//GEN-END:variables
}
