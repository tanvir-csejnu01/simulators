package dining_philosopher_package;

public class BuildSemaphore      // a basic counting  semaphore
{
  private int value;

  public BuildSemaphore(int value) 
  {
    this.value = value;
  }

  public synchronized void acquire() 
  {
    try
    {
      while (value <= 0) 
        wait(); 
    }
    catch (InterruptedException e) {}

    --value;
  }

  public synchronized void release() 
  {
    ++value;
    notifyAll();
  }
}
 