package dining_philosopher_package;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SleepUtilities
{
  private static final Random rand = new Random();


  public static void nap() 
  {
    int sleeptime =rand.nextInt(20000);
    try 
    { 
      Thread.sleep(sleeptime); 
    }
    catch (InterruptedException e) {}
  }
  public static void toEqualSleep()
  {
       try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(PhilosopherWithNoDeadlock.class.getName()).log(Level.SEVERE, null, ex);
            }
   }
  
  public static void toDeadlockSleep()
  {
        try {
            Thread.sleep(rand.nextInt(20000));
        } catch (InterruptedException ex) {
            Logger.getLogger(SleepUtilities.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}