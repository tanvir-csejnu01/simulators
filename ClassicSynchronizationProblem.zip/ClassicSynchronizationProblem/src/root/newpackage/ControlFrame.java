
package root.newpackage;

import editor_Pane.ViewTextEditor;



/**
 *
 * @author tanvir-pc
 */
public class ControlFrame extends javax.swing.JFrame {

   
    public ControlFrame() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        cs_bnt = new javax.swing.JRadioButtonMenuItem();
        dn_bnt = new javax.swing.JRadioButtonMenuItem();
        pc_bnt = new javax.swing.JRadioButtonMenuItem();
        sb_bnt = new javax.swing.JRadioButtonMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("  Simulation of Classic Synchronization Problems designed by Tanvir Ahmed Lincon");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setResizable(false);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/root/newpackage/pic.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jMenu1.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Exit");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Options");

        buttonGroup1.add(cs_bnt);
        cs_bnt.setText("Cigaratte-Smoker Problem");
        cs_bnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cs_bntActionPerformed(evt);
            }
        });
        jMenu2.add(cs_bnt);

        buttonGroup1.add(dn_bnt);
        dn_bnt.setText("Dining Philosopher Problem");
        dn_bnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dn_bntActionPerformed(evt);
            }
        });
        jMenu2.add(dn_bnt);

        buttonGroup1.add(pc_bnt);
        pc_bnt.setText("Producer Consumer problem");
        pc_bnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pc_bntActionPerformed(evt);
            }
        });
        jMenu2.add(pc_bnt);

        buttonGroup1.add(sb_bnt);
        sb_bnt.setText("Sleeping Barber Problem");
        sb_bnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sb_bntActionPerformed(evt);
            }
        });
        jMenu2.add(sb_bnt);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Help");

        jMenuItem2.setText("How To Use  It");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem2);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
        dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void dn_bntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dn_bntActionPerformed
        // TODO add your handling code here:
        if(dn_bnt.isSelected())
        {
            new dining_philosopher_package.PhilosopherJFrame().show();
         }
    }//GEN-LAST:event_dn_bntActionPerformed

    private void cs_bntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cs_bntActionPerformed
        // TODO add your handling code here:
       if(cs_bnt.isSelected())
       {
        new cigarette_smoker_newpackage.CSjFrame().show();   
        }
    }//GEN-LAST:event_cs_bntActionPerformed

    private void sb_bntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sb_bntActionPerformed
        // TODO add your handling code here:
        if(sb_bnt.isSelected())
        {
            new barber_newpackage.BarberShopInJframe().show();
         }
    }//GEN-LAST:event_sb_bntActionPerformed

    private void pc_bntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pc_bntActionPerformed

       // TODO add your handling code here:
        if(pc_bnt.isSelected())
        {
            new producer_consumer_newpackage.Simulator().show();
         }
    }//GEN-LAST:event_pc_bntActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        ViewTextEditor edt =new ViewTextEditor();
        edt.showTextMessage("/editor_Pane/help.html");
        edt.show();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new ControlFrame().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButtonMenuItem cs_bnt;
    private javax.swing.JRadioButtonMenuItem dn_bnt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButtonMenuItem pc_bnt;
    private javax.swing.JRadioButtonMenuItem sb_bnt;
    // End of variables declaration//GEN-END:variables
}
