package cigarette_smoker_newpackage;

import java.util.ArrayList;
import java.util.Random;

public class Table {
    
     // stores all elements that need to smoke.
    private ArrayList<String> allElements = new ArrayList<String>();
    // stores which elements that the agent will  keep in the table.
    private ArrayList<String> agentElements = new ArrayList<String>();
    // get randomly index number
    private int One;
    private int Two;

    public Table()
    {
        allElements.add("tobacco");
        allElements.add("paper");
        allElements.add("matches");
    }

    public void setAgentElements()
    {
        Random random = new Random();

        agentElements.clear();

        ArrayList<String> copyAllElements = (ArrayList<String>) allElements.clone();

        int element1 = random.nextInt(copyAllElements.size());
        agentElements.add(copyAllElements.get(element1));// get randomely second element.
         One =element1; // temporary ...
         
        copyAllElements.remove(element1);
        int element2 = random.nextInt(copyAllElements.size());
        agentElements.add(copyAllElements.get(element2)); // get randomely second element.
         Two =element2; // temporary...
    }

    public boolean isEmpty()
    {
        return (agentElements.size() == 0);
    }

    public synchronized String getAgentElements()
    {
        notifyAll();
        return agentElements.toString();
    }

    public synchronized String getSmokerElement(int pElement) //int pElement
    {
       // int pElement =new Random().nextInt(allElements.size());
        try {
            this.wait();
        } catch (Exception e) {}
        return allElements.get(pElement);
    }

    public boolean hasElement(String elementName)
    {
        return (agentElements.contains(elementName));
    }

    public synchronized void pause()
    {
        try {
            this.wait();
        } catch (Exception e) {}
    }
    public  int getElementOne()
    {
        return One;
     }
    public int getElementTwo()
    {
        return Two;
     }
}

