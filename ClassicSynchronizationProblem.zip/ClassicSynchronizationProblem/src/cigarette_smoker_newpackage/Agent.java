package cigarette_smoker_newpackage;

import javax.swing.Icon;

public class Agent extends Thread {

    private Table smokingtable;
    private CSjFrame csjFrame =new CSjFrame();
     private Icon [] icon =new Icon[3];
     
    public Agent(Table pSmokingtable,CSjFrame csjF)
    {
        this.smokingtable = pSmokingtable;
        this.csjFrame =csjF;
       icon[0]= new javax.swing.ImageIcon(getClass().getResource("tobacco.png"));
       icon[1]= new javax.swing.ImageIcon(getClass().getResource("paper.png"));
       icon[2]= new javax.swing.ImageIcon(getClass().getResource("match.png"));
    }

    @Override
    public void run()
    {
        while(csjFrame.isRunning==true)
        {
            try {
                Thread.sleep(5000);
            } catch (Exception e) {}
            smokingtable.setAgentElements();
            // this triggers the smoker-threads to look at the table
            output("The agents puts " + smokingtable.getAgentElements() + " on the table.");
            // pause the agent while one smoker thread is running
            pause();
        }
    }

    // wakes up next somker who is allowed to smoke.
    public synchronized void wake()
    {
        try
        {
            notify();
        } catch(Exception e){}
    }

//   wait who has not the required element.
    public synchronized void pause()
    {
        try
        {
            this.wait();
        } catch (Exception e) {}
    }

    private void output(String pOutput)
    {
       // System.out.println(pOutput);
        csjFrame.agentTable.setText(pOutput);
        if(smokingtable.getAgentElements().equals("[tobacco, paper]")){
        csjFrame.agentElement_1.setIcon(icon[0]);
        csjFrame.agentElement_2.setIcon(icon[1]);
         }
         else if(smokingtable.getAgentElements().equals("[paper, tobacco]")){
        csjFrame.agentElement_1.setIcon(icon[1]);
        csjFrame.agentElement_2.setIcon(icon[0]);
         }
        else  if(smokingtable.getAgentElements().equals("[tobacco, matches]"))
        {
        csjFrame.agentElement_1.setIcon(icon[0]);
        csjFrame.agentElement_2.setIcon(icon[2]); 
         }
      else  if(smokingtable.getAgentElements().equals("[matches, tobacco]"))
        {
        csjFrame.agentElement_1.setIcon(icon[2]);
        csjFrame.agentElement_2.setIcon(icon[0]); 
         }
      else  if(smokingtable.getAgentElements().equals("[paper, matches]"))
        {
        csjFrame.agentElement_1.setIcon(icon[1]);
        csjFrame.agentElement_2.setIcon(icon[2]); 
         }
       else if(smokingtable.getAgentElements().equals("[matches, paper]"))
        {
        csjFrame.agentElement_1.setIcon(icon[2]);
        csjFrame.agentElement_2.setIcon(icon[1]); 
         }
       else {
        csjFrame.agentElement_1.setIcon(null);
        csjFrame.agentElement_2.setIcon(null); 
             }
    }
}
