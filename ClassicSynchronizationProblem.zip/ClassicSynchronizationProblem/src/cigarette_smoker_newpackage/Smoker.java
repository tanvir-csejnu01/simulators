package cigarette_smoker_newpackage;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;

public class Smoker extends Thread {

    private Table smokingtable = new Table();
    private String element;
    private int elementNumber;
    private Agent controlAgent;
    private CSjFrame csj =new CSjFrame();
    private Icon [] icon =new Icon[8];

    public Smoker(Table pSmokingtable, int pElementNumber, String pName, Agent pAgent,CSjFrame f)
    {
        // only save the number of the element, we'll get the element's name while the thread is running
        elementNumber = pElementNumber;
        this.smokingtable = pSmokingtable;
        setName(pName);
        controlAgent = pAgent;
        this.csj =f;
        // temporary images 
       icon[0]= new javax.swing.ImageIcon(getClass().getResource("tobacco.png"));
       icon[1]= new javax.swing.ImageIcon(getClass().getResource("paper.png"));
       icon[2]= new javax.swing.ImageIcon(getClass().getResource("match.png"));
       icon[3]= new javax.swing.ImageIcon(getClass().getResource("rolling.png"));
       icon[4]= new javax.swing.ImageIcon(getClass().getResource("smoke.png"));
       icon[5]= new javax.swing.ImageIcon(getClass().getResource("telling.png"));
       icon[6]= new javax.swing.ImageIcon(getClass().getResource("finish.jpg"));
       icon[7]= new javax.swing.ImageIcon(getClass().getResource("unable.jpg"));
       
       
    }

    @Override
    public void run()
    {
        while(csj.isRunning==true)
        {
            //int el =new Random().nextInt(3);
            element = smokingtable.getSmokerElement(elementNumber); //elementNumber

            if (!smokingtable.hasElement(element) && !smokingtable.isEmpty())
            {
                try {
                    output(getName() + " has " + element + ".");
                    csj.picAnimation[elementNumber].setIcon(icon[elementNumber]);
                     Thread.sleep(5000);
                    try {
                        doSmoke();
                        output(getName() + " tells the agent to start the next round.");
                   csj.picAnimation[elementNumber].setIcon(icon[5]);
                        // the thread tells the agent to continue
                        controlAgent.wake();
                    } catch (Exception e) {}
                } catch (InterruptedException ex) {Logger.getLogger(Smoker.class.getName()).log(Level.SEVERE, null, ex);}

            }
            else{
                   output(getName()+" is unable to smoke.");
                   csj.picAnimation[elementNumber].setIcon(icon[7]);
                  }
        }
    }

    public synchronized void doSmoke() throws Exception
    {
        output(getName() + " rolls the cigarette.");
       // csj.smokersStatus[elementNumber]
        //.setText(getName()+ " rolls the cigarette.");
    csj.picAnimation[elementNumber].setIcon(icon[3]);
        Thread.sleep(5000);
        output(getName() + " smokes.");
         //csj.smokersStatus[elementNumber]
        //.setText(getName()+ " smokes.");
      csj.picAnimation[elementNumber].setIcon(icon[4]);
        Thread.sleep(5000);
        output(getName() + " has finished smoking !");
        // csj.smokersStatus[elementNumber]
        //.setText(getName()+ " has finished !");
         csj.picAnimation[elementNumber].setIcon(icon[6]);
          Thread.sleep(5000);
    }

    private void output(String pOutput)
    {
       // System.out.println(pOutput);
       csj.smokersStatus[elementNumber].setText(pOutput);
       
    }
}
